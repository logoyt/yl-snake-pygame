import pygame as pg

FIELD = 16, 16
TILE = 64
WIN_SIZE = pg.Rect(0, 0, (FIELD[0] + 1) * TILE, (FIELD[1] + 1) * TILE)
FPS = 100
BEST_SCORE = 'best_score.txt'
